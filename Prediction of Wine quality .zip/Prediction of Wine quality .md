### Mayouran VARATHALINGAM 


## <center><font color=#3a0ca3>Prediction of wine quality based on its composition</font></center>


```python
import pandas as pd
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.pyplot as plt
import seaborn as sns
from IPython.display import Markdown as md
from sklearn.preprocessing import StandardScaler
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import *
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import VotingClassifier
```

## <font color=#3a0ca3>1. Analysis of the dataset:</font> 


```python
dfWine = pd.read_csv("winequality-white.csv", sep=";")
```


```python
dfWine.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.0</td>
      <td>0.27</td>
      <td>0.36</td>
      <td>20.7</td>
      <td>0.045</td>
      <td>45.0</td>
      <td>170.0</td>
      <td>1.0010</td>
      <td>3.00</td>
      <td>0.45</td>
      <td>8.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6.3</td>
      <td>0.30</td>
      <td>0.34</td>
      <td>1.6</td>
      <td>0.049</td>
      <td>14.0</td>
      <td>132.0</td>
      <td>0.9940</td>
      <td>3.30</td>
      <td>0.49</td>
      <td>9.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.1</td>
      <td>0.28</td>
      <td>0.40</td>
      <td>6.9</td>
      <td>0.050</td>
      <td>30.0</td>
      <td>97.0</td>
      <td>0.9951</td>
      <td>3.26</td>
      <td>0.44</td>
      <td>10.1</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfWine.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4898 entries, 0 to 4897
    Data columns (total 12 columns):
    fixed acidity           4898 non-null float64
    volatile acidity        4898 non-null float64
    citric acid             4898 non-null float64
    residual sugar          4898 non-null float64
    chlorides               4898 non-null float64
    free sulfur dioxide     4898 non-null float64
    total sulfur dioxide    4898 non-null float64
    density                 4898 non-null float64
    pH                      4898 non-null float64
    sulphates               4898 non-null float64
    alcohol                 4898 non-null float64
    quality                 4898 non-null int64
    dtypes: float64(11), int64(1)
    memory usage: 459.3 KB
    

We can see that there are not any **<font color=#3a0ca3>null values</font>** and **<font color=#3a0ca3>all the datatypes</font>** seem **<font color=#3a0ca3>correct.</font>**


```python
dfWine.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6.854788</td>
      <td>0.278241</td>
      <td>0.334192</td>
      <td>6.391415</td>
      <td>0.045772</td>
      <td>35.308085</td>
      <td>138.360657</td>
      <td>0.994027</td>
      <td>3.188267</td>
      <td>0.489847</td>
      <td>10.514267</td>
      <td>5.877909</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.843868</td>
      <td>0.100795</td>
      <td>0.121020</td>
      <td>5.072058</td>
      <td>0.021848</td>
      <td>17.007137</td>
      <td>42.498065</td>
      <td>0.002991</td>
      <td>0.151001</td>
      <td>0.114126</td>
      <td>1.230621</td>
      <td>0.885639</td>
    </tr>
    <tr>
      <th>min</th>
      <td>3.800000</td>
      <td>0.080000</td>
      <td>0.000000</td>
      <td>0.600000</td>
      <td>0.009000</td>
      <td>2.000000</td>
      <td>9.000000</td>
      <td>0.987110</td>
      <td>2.720000</td>
      <td>0.220000</td>
      <td>8.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.300000</td>
      <td>0.210000</td>
      <td>0.270000</td>
      <td>1.700000</td>
      <td>0.036000</td>
      <td>23.000000</td>
      <td>108.000000</td>
      <td>0.991723</td>
      <td>3.090000</td>
      <td>0.410000</td>
      <td>9.500000</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>6.800000</td>
      <td>0.260000</td>
      <td>0.320000</td>
      <td>5.200000</td>
      <td>0.043000</td>
      <td>34.000000</td>
      <td>134.000000</td>
      <td>0.993740</td>
      <td>3.180000</td>
      <td>0.470000</td>
      <td>10.400000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.300000</td>
      <td>0.320000</td>
      <td>0.390000</td>
      <td>9.900000</td>
      <td>0.050000</td>
      <td>46.000000</td>
      <td>167.000000</td>
      <td>0.996100</td>
      <td>3.280000</td>
      <td>0.550000</td>
      <td>11.400000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>14.200000</td>
      <td>1.100000</td>
      <td>1.660000</td>
      <td>65.800000</td>
      <td>0.346000</td>
      <td>289.000000</td>
      <td>440.000000</td>
      <td>1.038980</td>
      <td>3.820000</td>
      <td>1.080000</td>
      <td>14.200000</td>
      <td>9.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
cmap = LinearSegmentedColormap.from_list('mycmap', ['#4cc9f0','#4361ee','#3a0ca3'])

plt.figure(figsize=(13,8))
ax = sns.heatmap(dfWine.corr().round(decimals=2), cmap=cmap, annot=True)
plt.title("Correlation Matrix", fontsize=20)
plt.show()
```


    
![png](output_9_0.png)
    


The feature **<font color=#3a0ca3>alcohol</font>** seems to have a higher correlation with the wine **<font color=#3a0ca3>quality</font>**, with a correlation of **<font color=#3a0ca3>0.44</font>**.  

Our goal here is to predict the quality of a wine based on its composition. So in our dataset, the **<font color=#3a0ca3>target variable</font>** will be **<font color=#3a0ca3>"quality"</font>**.


```python
columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']
features = dfWine[columns]
target = dfWine['quality']
```


```python
scaler = StandardScaler()
scaler.fit(features)
scaled_features = scaler.transform(features)
```


```python
colorPalette = ['#4cc9f0','#4361ee','#3a0ca3']
fig = plt.figure(figsize=(30,15))
sns.boxplot(data=scaled_features, palette=colorPalette)
# plt.axes().set_xticklabels(['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol'], fontsize=13)
plt.xticks(np.arange(11),['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol'], fontsize=15)
plt.yticks(fontsize=15)
plt.title("Outliers by features\n",fontsize=30)
```




    Text(0.5, 1.0, 'Outliers by features\n')




    
![png](output_14_1.png)
    


Features like **<font color=#3a0ca3>"chlorides"</font>** or **<font color=#3a0ca3>"volatile acidity"</font>** present many **<font color=#3a0ca3>outliers</font>**. Let's treat them by replacing the outliers in each features by the **<font color=#3a0ca3>median</font>**.


```python
df_scaled_features = pd.DataFrame(scaled_features)
df_scaled_features.columns= ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']
df_scaled_features.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.172097</td>
      <td>-0.081770</td>
      <td>0.213280</td>
      <td>2.821349</td>
      <td>-0.035355</td>
      <td>0.569932</td>
      <td>0.744565</td>
      <td>2.331512</td>
      <td>-1.246921</td>
      <td>-0.349184</td>
      <td>-1.393152</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.657501</td>
      <td>0.215896</td>
      <td>0.048001</td>
      <td>-0.944765</td>
      <td>0.147747</td>
      <td>-1.253019</td>
      <td>-0.149685</td>
      <td>-0.009154</td>
      <td>0.740029</td>
      <td>0.001342</td>
      <td>-0.824276</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.475751</td>
      <td>0.017452</td>
      <td>0.543838</td>
      <td>0.100282</td>
      <td>0.193523</td>
      <td>-0.312141</td>
      <td>-0.973336</td>
      <td>0.358665</td>
      <td>0.475102</td>
      <td>-0.436816</td>
      <td>-0.336667</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.409125</td>
      <td>-0.478657</td>
      <td>-0.117278</td>
      <td>0.415768</td>
      <td>0.559727</td>
      <td>0.687541</td>
      <td>1.121091</td>
      <td>0.525855</td>
      <td>0.011480</td>
      <td>-0.787342</td>
      <td>-0.499203</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.409125</td>
      <td>-0.478657</td>
      <td>-0.117278</td>
      <td>0.415768</td>
      <td>0.559727</td>
      <td>0.687541</td>
      <td>1.121091</td>
      <td>0.525855</td>
      <td>0.011480</td>
      <td>-0.787342</td>
      <td>-0.499203</td>
    </tr>
  </tbody>
</table>
</div>




```python
for i in df_scaled_features.columns:
    for j in df_scaled_features[i]:
        q1 = df_scaled_features[i].quantile(0.25)
        q3 = df_scaled_features[i].quantile(0.75)
        iqr = q3-q1
        Lower_tail = q1 - 1.5 * iqr
        Upper_tail = q3 + 1.5 * iqr
        if j > Upper_tail or j < Lower_tail:
            df_scaled_features[i] = df_scaled_features[i].replace(j, np.mean(df_scaled_features[i]))

```


```python
fig = plt.figure(figsize=(20,10))
sns.boxplot(data=df_scaled_features, palette=colorPalette)
plt.title("Processed outliers by features\n",fontsize=18)
```




    Text(0.5, 1.0, 'Processed outliers by features\n')




    
![png](output_18_1.png)
    


We can see that we don't have **<font color=#3a0ca3>outlier</font>** anymore.

## <font color=#3a0ca3>2. Machine Learning and Prediction:</font> 

### <font color=#3a0ca3>a. Regression</font> 

### <font color="#f72585">Linear Regression</font>


```python
#We will do the regression only with the feature alcohol
alcohol = df_scaled_features.iloc[:,10].values.reshape((len(target),1))
targetReg = target.values.reshape((len(target),1))
print(alcohol.shape)
print(targetReg.shape)
```

    (4898, 1)
    (4898, 1)
    


```python
X_train,X_test,y_train,y_test = train_test_split(alcohol, targetReg, test_size=0.2, random_state=0)

print(X_train)
```

    [[-0.01159456]
     [ 1.53249956]
     [ 0.80108656]
     ...
     [-1.39315246]
     [ 0.23220977]
     [-0.41793512]]
    


```python
lin_regr = linear_model.LinearRegression()
lin_regr.fit(X_train, y_train)
```




    LinearRegression()




```python
predicted_y = lin_regr.predict(X_test)
```


```python
md(f"Mean squared error: **<font color=#3a0ca3>{mean_squared_error(y_test,predicted_y):.2f}</font>**")
```




Mean squared error: **<font color=#3a0ca3>0.73</font>**




```python
md(f"Root mean squared error: **<font color=#3a0ca3>{mean_squared_error(y_test,predicted_y, squared=False):.2f}</font>**")
```




Root mean squared error: **<font color=#3a0ca3>0.85</font>**




```python
fig = plt.figure(figsize=(10,8))
plt.plot(alcohol, targetReg, "b.", color = "#3a0ca3")
plt.xlabel("Alcohol", fontsize=15)
plt.ylabel("Quality", fontsize=15)
plt.tight_layout()
```


    
![png](output_29_0.png)
    



```python
fig = plt.figure(figsize=(10,8))
plt.plot(X_test,predicted_y, "r-", linewidth=2, label="Target Predictions", color="#f72585")
plt.plot( X_train,y_train, "b.", color="#3a0ca3")
plt.xlabel("Alcohol", fontsize=15)
plt.ylabel("Quality", fontsize=15)
plt.legend(loc="upper left", fontsize=13)
plt.show()
```


    
![png](output_30_0.png)
    



```python
df_linear_regr = pd.DataFrame({'Actual': y_test.flatten(), 'Predicted': predicted_y.flatten()})
df_linear_regr.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5</td>
      <td>5.948460</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6</td>
      <td>5.668554</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7</td>
      <td>5.979560</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8</td>
      <td>6.632673</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>5.761856</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_linear_regr_bar = df_linear_regr.head(25)
df_linear_regr_bar.plot(kind='bar',color = ['#3a0ca3', '#f72585'], figsize=(16,10))
plt.title("Prediction of wine quality based on alcohol\n",fontsize=18)
plt.xlabel("Alcohol", fontsize=15)
plt.ylabel("Quality", fontsize=15)
```




    Text(0, 0.5, 'Quality')




    
![png](output_32_1.png)
    


### <font color="#f72585">Logistic regression</font>


```python
X_train,X_test,y_train,y_test = train_test_split(scaled_features, targetReg, test_size=0.2, random_state=0)
```


```python
log_reg = linear_model.LogisticRegression(solver ='newton-cg', multi_class='multinomial',max_iter=1000)
log_reg.fit(X_train,y_train.ravel())
```




    LogisticRegression(max_iter=1000, multi_class='multinomial', solver='newton-cg')




```python
y_hat = log_reg.predict(X_test)
```


```python
acc = accuracy_score(y_hat,y_test)
md(f"Accuracy: **<font color=#3a0ca3>{100*acc:.2f}%</font>**")
```




Accuracy: **<font color=#3a0ca3>51.22%</font>**




```python
md(f"Mean squared error: **<font color=#3a0ca3>{mean_squared_error(y_test,y_hat):.2f}</font>**")
```




Mean squared error: **<font color=#3a0ca3>0.73</font>**




```python
md(f"Root mean squared error: **<font color=#3a0ca3>{mean_squared_error(y_test,y_hat, squared=False):.2f}</font>**")
```




Root mean squared error: **<font color=#3a0ca3>0.85</font>**




```python
df_logist_regr = pd.DataFrame({'Actual': y_test.flatten(), 'Predicted': y_hat.flatten()})
df_logist_regr.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_logist_regr_bar = df_logist_regr.head(25)
df_logist_regr_bar.plot(kind='bar',color = ['#3a0ca3', '#f72585'], figsize=(16,10))
plt.title("Prediction of wine quality based on alcohol",fontsize=18)
plt.xlabel("Alcohol", fontsize=15)
plt.ylabel("Quality", fontsize=15)
```




    Text(0, 0.5, 'Quality')




    
![png](output_41_1.png)
    


### <font color=#3a0ca3>b. Classification</font> 

### <font color="#f72585">KNN</font>


```python
X_trainKnn,X_testKnn,y_trainKnn,y_testKnn = train_test_split(df_scaled_features, targetReg, test_size=0.2, random_state=0)
```


```python
Knn = KNeighborsClassifier (n_neighbors=10,p=1)
Knn.fit(X_trainKnn,y_trainKnn.ravel())
```




    KNeighborsClassifier(n_neighbors=10, p=1)




```python
y_pred_knn=Knn.predict(X_testKnn)
```


```python
print("Wrong values predicted out of total values : ")
print((y_testKnn!=y_pred_knn).sum(),'/',((y_testKnn==y_pred_knn).sum()+(y_testKnn!=y_pred_knn).sum()))
```

    Wrong values predicted out of total values : 
    630176 / 960400
    


```python
md(f"Accuracy using **<font color=#3a0ca3>KNN</font>** is: **<font color=#3a0ca3>{100*accuracy_score(y_testKnn,y_pred_knn):.2f}%</font>**")
```




Accuracy using **<font color=#3a0ca3>KNN</font>** is: **<font color=#3a0ca3>51.02%</font>**




```python
adjusted_rand_score(y_testKnn.ravel(), y_pred_knn)
```




    0.09186932267667855




```python
dfKnn = pd.DataFrame(X_testKnn)
```


```python
dfKnn.columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']
```


```python
dfKnn['True'] = y_testKnn
dfKnn['Predict'] = y_pred_knn
dfKnn.reset_index(inplace = True, drop = True)
```


```python
dfKnn.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>True</th>
      <th>Predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.527639</td>
      <td>0.414339</td>
      <td>0.130641</td>
      <td>-0.984201</td>
      <td>0.193523</td>
      <td>-1.605848</td>
      <td>0.579835</td>
      <td>-0.530788</td>
      <td>0.342639</td>
      <td>-0.612079</td>
      <td>0.150942</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.172097</td>
      <td>0.315117</td>
      <td>-0.613115</td>
      <td>0.198872</td>
      <td>-0.080834</td>
      <td>-0.429751</td>
      <td>0.509236</td>
      <td>0.458979</td>
      <td>-0.385910</td>
      <td>-0.261553</td>
      <td>-0.580471</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.883181</td>
      <td>-1.371654</td>
      <td>-0.046493</td>
      <td>-0.944765</td>
      <td>-0.264233</td>
      <td>-0.488556</td>
      <td>-0.832138</td>
      <td>-0.811668</td>
      <td>-0.783300</td>
      <td>-0.787342</td>
      <td>0.232210</td>
      <td>7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-2.198183</td>
      <td>0.116674</td>
      <td>-0.030487</td>
      <td>-0.136332</td>
      <td>-0.493110</td>
      <td>1.099175</td>
      <td>0.391572</td>
      <td>-1.426929</td>
      <td>0.541334</td>
      <td>-1.313131</td>
      <td>1.938840</td>
      <td>8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.013043</td>
      <td>0.017452</td>
      <td>-0.943673</td>
      <td>1.135471</td>
      <td>0.101972</td>
      <td>0.393517</td>
      <td>0.579835</td>
      <td>0.559293</td>
      <td>0.077712</td>
      <td>-0.261553</td>
      <td>-0.336667</td>
      <td>5</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfKnn['True'] = pd.Categorical(dfKnn['True'])
dfKnn['Predict'] = pd.Categorical(dfKnn['Predict'])
```


```python
dfKnn.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 980 entries, 0 to 979
    Data columns (total 13 columns):
    fixed acidity           980 non-null float64
    volatile acidity        980 non-null float64
    citric acid             980 non-null float64
    residual sugar          980 non-null float64
    chlorides               980 non-null float64
    free sulfur dioxide     980 non-null float64
    total sulfur dioxide    980 non-null float64
    density                 980 non-null float64
    pH                      980 non-null float64
    sulphates               980 non-null float64
    alcohol                 980 non-null float64
    True                    980 non-null category
    Predict                 980 non-null category
    dtypes: category(2), float64(11)
    memory usage: 86.6 KB
    


```python
paletteScatter = {3:'#717EC3', 4:'#3A86FF', 5:'#8338EC', 6:'#FF006E', 7:'#FB5607', 8:'#FFBE0B'}
fig = plt.figure(figsize=(15,10), dpi=200)
plt.suptitle("KNN prediction result",fontsize=18, y=0.92)
plt.subplot(121)
sns.scatterplot(data=dfKnn, x=dfKnn['alcohol'], y=dfKnn['density'], hue=dfKnn['Predict'], palette=paletteScatter)
plt.ylim(ymax=3.0)
plt.xlabel("Alcohol",fontsize=15)
plt.ylabel("Density",fontsize=15)
plt.subplot(122)
sns.scatterplot(data=dfKnn, x=dfKnn['alcohol'], y=dfKnn['density'], hue=dfKnn['True'], palette=paletteScatter)
plt.ylim(ymax=3.0)
plt.xlabel("Alcohol",fontsize=15)
plt.ylabel("Density",fontsize=15)
```

    C:\Users\mayou\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:3610: MatplotlibDeprecationWarning: 
    The `ymax` argument was deprecated in Matplotlib 3.0 and will be removed in 3.2. Use `top` instead.
      alternative='`top`', obj_type='argument')
    C:\Users\mayou\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:3610: MatplotlibDeprecationWarning: 
    The `ymax` argument was deprecated in Matplotlib 3.0 and will be removed in 3.2. Use `top` instead.
      alternative='`top`', obj_type='argument')
    




    Text(0, 0.5, 'Density')




    
![png](output_56_2.png)
    


### <font color="#f72585">Decision Tree</font>


```python
X_trainDT,X_testDT,y_trainDT,y_testDT = train_test_split(df_scaled_features, targetReg, test_size=0.2, random_state=0)
```


```python
tree = DecisionTreeClassifier(max_depth=4,random_state=0)
tree.fit(X_trainDT, y_trainDT.ravel())
```




    DecisionTreeClassifier(max_depth=4, random_state=0)




```python
y_pred_dt = tree.predict(X_testDT)
```


```python
print(classification_report(y_testDT, y_pred_dt.round(), digits=3))
```

                  precision    recall  f1-score   support
    
               3      0.000     0.000     0.000         9
               4      0.000     0.000     0.000        51
               5      0.535     0.522     0.528       295
               6      0.480     0.638     0.548       409
               7      0.392     0.317     0.350       183
               8      0.000     0.000     0.000        33
    
        accuracy                          0.483       980
       macro avg      0.234     0.246     0.238       980
    weighted avg      0.434     0.483     0.453       980
    
    

    C:\Users\mayou\Anaconda3\lib\site-packages\sklearn\metrics\_classification.py:1318: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    C:\Users\mayou\Anaconda3\lib\site-packages\sklearn\metrics\_classification.py:1318: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    C:\Users\mayou\Anaconda3\lib\site-packages\sklearn\metrics\_classification.py:1318: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    


```python
print("Wrong values predicted out of total values : ")
print((y_testDT!=y_pred_dt).sum(),'/',((y_testDT==y_pred_dt).sum()+(y_testDT!=y_pred_dt).sum()))
```

    Wrong values predicted out of total values : 
    625860 / 960400
    


```python
md(f"Accuracy using **<font color=#3a0ca3>Decision Tree</font>** is: **<font color=#3a0ca3>{100*accuracy_score(y_testDT,y_pred_dt):.2f}%</font>**")
```




Accuracy using **<font color=#3a0ca3>Decision Tree</font>** is: **<font color=#3a0ca3>48.27%</font>**




```python
adjusted_rand_score(y_testDT.ravel(), y_pred_dt)
```




    0.07016693981479545




```python
dfTree = pd.DataFrame(X_testDT)
dfTree.columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']
dfTree['True'] = y_testDT
dfTree['Predict'] = y_pred_dt
dfTree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>True</th>
      <th>Predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2762</th>
      <td>0.527639</td>
      <td>0.414339</td>
      <td>0.130641</td>
      <td>-0.984201</td>
      <td>0.193523</td>
      <td>-1.605848</td>
      <td>0.579835</td>
      <td>-0.530788</td>
      <td>0.342639</td>
      <td>-0.612079</td>
      <td>0.150942</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>42</th>
      <td>0.172097</td>
      <td>0.315117</td>
      <td>-0.613115</td>
      <td>0.198872</td>
      <td>-0.080834</td>
      <td>-0.429751</td>
      <td>0.509236</td>
      <td>0.458979</td>
      <td>-0.385910</td>
      <td>-0.261553</td>
      <td>-0.580471</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1419</th>
      <td>0.883181</td>
      <td>-1.371654</td>
      <td>-0.046493</td>
      <td>-0.944765</td>
      <td>-0.264233</td>
      <td>-0.488556</td>
      <td>-0.832138</td>
      <td>-0.811668</td>
      <td>-0.783300</td>
      <td>-0.787342</td>
      <td>0.232210</td>
      <td>7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3664</th>
      <td>-2.198183</td>
      <td>0.116674</td>
      <td>-0.030487</td>
      <td>-0.136332</td>
      <td>-0.493110</td>
      <td>1.099175</td>
      <td>0.391572</td>
      <td>-1.426929</td>
      <td>0.541334</td>
      <td>-1.313131</td>
      <td>1.938840</td>
      <td>8</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2125</th>
      <td>-1.013043</td>
      <td>0.017452</td>
      <td>-0.943673</td>
      <td>1.135471</td>
      <td>0.101972</td>
      <td>0.393517</td>
      <td>0.579835</td>
      <td>0.559293</td>
      <td>0.077712</td>
      <td>-0.261553</td>
      <td>-0.336667</td>
      <td>5</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfTree.reset_index(inplace = True, drop = True)
```


```python
dfTree.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>True</th>
      <th>Predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.527639</td>
      <td>0.414339</td>
      <td>0.130641</td>
      <td>-0.984201</td>
      <td>0.193523</td>
      <td>-1.605848</td>
      <td>0.579835</td>
      <td>-0.530788</td>
      <td>0.342639</td>
      <td>-0.612079</td>
      <td>0.150942</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.172097</td>
      <td>0.315117</td>
      <td>-0.613115</td>
      <td>0.198872</td>
      <td>-0.080834</td>
      <td>-0.429751</td>
      <td>0.509236</td>
      <td>0.458979</td>
      <td>-0.385910</td>
      <td>-0.261553</td>
      <td>-0.580471</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.883181</td>
      <td>-1.371654</td>
      <td>-0.046493</td>
      <td>-0.944765</td>
      <td>-0.264233</td>
      <td>-0.488556</td>
      <td>-0.832138</td>
      <td>-0.811668</td>
      <td>-0.783300</td>
      <td>-0.787342</td>
      <td>0.232210</td>
      <td>7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-2.198183</td>
      <td>0.116674</td>
      <td>-0.030487</td>
      <td>-0.136332</td>
      <td>-0.493110</td>
      <td>1.099175</td>
      <td>0.391572</td>
      <td>-1.426929</td>
      <td>0.541334</td>
      <td>-1.313131</td>
      <td>1.938840</td>
      <td>8</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.013043</td>
      <td>0.017452</td>
      <td>-0.943673</td>
      <td>1.135471</td>
      <td>0.101972</td>
      <td>0.393517</td>
      <td>0.579835</td>
      <td>0.559293</td>
      <td>0.077712</td>
      <td>-0.261553</td>
      <td>-0.336667</td>
      <td>5</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfTree['True'] = pd.Categorical(dfTree['True'])
dfTree['Predict'] = pd.Categorical(dfTree['Predict'])
dfTree.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 980 entries, 0 to 979
    Data columns (total 13 columns):
    fixed acidity           980 non-null float64
    volatile acidity        980 non-null float64
    citric acid             980 non-null float64
    residual sugar          980 non-null float64
    chlorides               980 non-null float64
    free sulfur dioxide     980 non-null float64
    total sulfur dioxide    980 non-null float64
    density                 980 non-null float64
    pH                      980 non-null float64
    sulphates               980 non-null float64
    alcohol                 980 non-null float64
    True                    980 non-null category
    Predict                 980 non-null category
    dtypes: category(2), float64(11)
    memory usage: 86.5 KB
    


```python
paletteScatter = {3:'#717EC3', 4:'#3A86FF', 5:'#8338EC', 6:'#FF006E', 7:'#FB5607', 8:'#FFBE0B'}
fig = plt.figure(figsize=(15,10))
plt.suptitle("Decision Tree prediction result",fontsize=18, y=0.92)
plt.subplot(121)
sns.scatterplot(data=dfTree, x=dfTree['alcohol'], y=dfTree['density'], hue=dfTree['Predict'], palette=paletteScatter)
plt.ylim(ymax=3.0)
plt.xlabel("Alcohol",fontsize=15)
plt.ylabel("Density",fontsize=15)
plt.subplot(122)
sns.scatterplot(data=dfTree, x=dfTree['alcohol'], y=dfTree['density'], hue=dfTree['True'], palette=paletteScatter)
plt.ylim(ymax=3.0)
plt.xlabel("Alcohol",fontsize=15)
plt.ylabel("Density",fontsize=15)
```

    C:\Users\mayou\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:3610: MatplotlibDeprecationWarning: 
    The `ymax` argument was deprecated in Matplotlib 3.0 and will be removed in 3.2. Use `top` instead.
      alternative='`top`', obj_type='argument')
    C:\Users\mayou\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:3610: MatplotlibDeprecationWarning: 
    The `ymax` argument was deprecated in Matplotlib 3.0 and will be removed in 3.2. Use `top` instead.
      alternative='`top`', obj_type='argument')
    




    Text(0, 0.5, 'Density')




    
![png](output_69_2.png)
    


### <font color="#f72585">SVC</font>


```python
X_trainSvc,X_testSvc,y_trainSvc,y_testSvc = train_test_split(df_scaled_features, targetReg, test_size=0.2, random_state=0)
```


```python
svc_model = SVC()
svc_model.fit(X_train, y_train.ravel())

y_pred_svc = svc_model.predict(X_testSvc)
```

    C:\Users\mayou\Anaconda3\lib\site-packages\sklearn\base.py:444: UserWarning: X has feature names, but SVC was fitted without feature names
      f"X has feature names, but {self.__class__.__name__} was fitted without"
    


```python
md(f"Accuracy using **<font color=#3a0ca3>SVC</font>** is: **<font color=#3a0ca3>{100*accuracy_score(y_testSvc,y_pred_svc):.2f}%</font>**")
```




Accuracy using **<font color=#3a0ca3>SVC</font>** is: **<font color=#3a0ca3>53.47%</font>**




```python
print(adjusted_rand_score(y_testSvc.ravel(), y_pred_svc))
```

    0.1133982159886251
    


```python
dfSvc = pd.DataFrame(X_testSvc)
dfSvc.columns = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']
```


```python
dfSvc['True'] = y_testSvc
dfSvc['Predict'] = y_pred_svc
dfSvc.reset_index(inplace = True, drop = True)
dfSvc.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>True</th>
      <th>Predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.527639</td>
      <td>0.414339</td>
      <td>0.130641</td>
      <td>-0.984201</td>
      <td>0.193523</td>
      <td>-1.605848</td>
      <td>0.579835</td>
      <td>-0.530788</td>
      <td>0.342639</td>
      <td>-0.612079</td>
      <td>0.150942</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.172097</td>
      <td>0.315117</td>
      <td>-0.613115</td>
      <td>0.198872</td>
      <td>-0.080834</td>
      <td>-0.429751</td>
      <td>0.509236</td>
      <td>0.458979</td>
      <td>-0.385910</td>
      <td>-0.261553</td>
      <td>-0.580471</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.883181</td>
      <td>-1.371654</td>
      <td>-0.046493</td>
      <td>-0.944765</td>
      <td>-0.264233</td>
      <td>-0.488556</td>
      <td>-0.832138</td>
      <td>-0.811668</td>
      <td>-0.783300</td>
      <td>-0.787342</td>
      <td>0.232210</td>
      <td>7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-2.198183</td>
      <td>0.116674</td>
      <td>-0.030487</td>
      <td>-0.136332</td>
      <td>-0.493110</td>
      <td>1.099175</td>
      <td>0.391572</td>
      <td>-1.426929</td>
      <td>0.541334</td>
      <td>-1.313131</td>
      <td>1.938840</td>
      <td>8</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.013043</td>
      <td>0.017452</td>
      <td>-0.943673</td>
      <td>1.135471</td>
      <td>0.101972</td>
      <td>0.393517</td>
      <td>0.579835</td>
      <td>0.559293</td>
      <td>0.077712</td>
      <td>-0.261553</td>
      <td>-0.336667</td>
      <td>5</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig = plt.figure(figsize=(15,10))
plt.suptitle("SVC prediction result",fontsize=18, y=0.92)
plt.subplot(121)
sns.scatterplot(data=dfSvc, x=dfSvc['alcohol'], y=dfSvc['density'], hue=dfSvc['Predict'], palette=paletteScatter)
plt.ylim(ymax=3.0)
plt.xlabel("Alcohol",fontsize=15)
plt.ylabel("Density",fontsize=15)
plt.subplot(122)
sns.scatterplot(data=dfSvc, x=dfSvc['alcohol'], y=dfSvc['density'], hue=dfSvc['True'], palette=paletteScatter)
plt.ylim(ymax=3.0)
plt.xlabel("Alcohol",fontsize=15)
plt.ylabel("Density",fontsize=15)
```

    C:\Users\mayou\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:3610: MatplotlibDeprecationWarning: 
    The `ymax` argument was deprecated in Matplotlib 3.0 and will be removed in 3.2. Use `top` instead.
      alternative='`top`', obj_type='argument')
    C:\Users\mayou\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:3610: MatplotlibDeprecationWarning: 
    The `ymax` argument was deprecated in Matplotlib 3.0 and will be removed in 3.2. Use `top` instead.
      alternative='`top`', obj_type='argument')
    




    Text(0, 0.5, 'Density')




    
![png](output_77_2.png)
    



```python
knnAccuracy = round(100*accuracy_score(y_testKnn,y_pred_knn),2)
dtAccuracy = round(100*accuracy_score(y_testDT,y_pred_dt),2)
svcAccuracy = round(100*accuracy_score(y_testSvc,y_pred_svc),2)
```


```python
fig = plt.figure(figsize=(10,8))
plt.bar(x=['KNN','Decision Tree', 'SVC'], height=[knnAccuracy,dtAccuracy,svcAccuracy], 
        width=0.6, 
        color=['#cfd2cd','#e5e6e4','#FF006E'])
plt.text(0,knnAccuracy-5,f'{knnAccuracy}%',ha='center',fontsize=15, fontweight='bold')
plt.text(1,dtAccuracy-5,f'{dtAccuracy}%',ha='center',fontsize=15, fontweight='bold')
plt.text(2,svcAccuracy-5,f'{svcAccuracy}%',ha='center',fontsize=15, fontweight='bold', color='white')
plt.text(0.16,0.89,'SVC',transform=fig.transFigure, fontsize=16, fontweight='bold', color='#FF006E')
plt.text(0.22,0.89,'is the model that has the',transform=fig.transFigure, fontsize=16)
plt.text(0.51,0.89,'highest accuracy.',transform=fig.transFigure, fontsize=16, fontweight='bold', color='#FF006E')
plt.xticks(fontsize=12)
plt.yticks([])
plt.title("Models' accuracy comparison", fontsize=18, y=1.08)
plt.xlabel('Models',fontsize=15)
plt.gca().get_xticklabels()[2].set_color('#FF006E') 
sns.despine(left=True)
```


    
![png](output_79_0.png)
    


### <font color=#3a0ca3>c. Optimisation</font> 

### <font color="#f72585">KNN</font>


```python
knn = KNeighborsClassifier()
param_grid = {"n_neighbors": np.arange(1, 32),
              "weights":['uniform','distance'],
              "metric":['minkowski','euclidean','manhattan']
             }
knn_gscv = GridSearchCV(knn, param_grid, cv=5)
knn_gscv.fit(X_trainKnn, y_trainKnn.ravel())
```




    GridSearchCV(cv=5, estimator=KNeighborsClassifier(),
                 param_grid={'metric': ['minkowski', 'euclidean', 'manhattan'],
                             'n_neighbors': array([ 1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16, 17,
           18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]),
                             'weights': ['uniform', 'distance']})




```python
knn_gscv.best_params_
```




    {'metric': 'manhattan', 'n_neighbors': 28, 'weights': 'distance'}




```python
knn_gscv.best_score_
```




    0.6641195558683244




```python
modelKnn = knn_gscv.best_estimator_
```


```python
knnOpti = modelKnn.score(X_testKnn,y_testKnn)
md(f"**<font color=#3a0ca3>Optimised KNN</font>** accuracy: **<font color=#3a0ca3>{100*knnOpti:.2f}%</font>**")
```




**<font color=#3a0ca3>Optimised KNN</font>** accuracy: **<font color=#3a0ca3>63.27%</font>**



We can see that the best **<font color='#3a0ca3'>hyper-parameters</font>** are:  
- **metric**: **<font color='#3a0ca3'>Manhattan</font>**  
- **n_neighbors**: **<font color='#3a0ca3'>28</font>**  
- **weights**: **<font color='#3a0ca3'>distance</font>**  
  
The optimised model's accuracy is **<font color='#3a0ca3'>63.27%</font>** while the initial one is **<font color='#3a0ca3'>51.02%</font>.**

### <font color="#f72585">Decision Tree</font>


```python
dec_tree = DecisionTreeClassifier()
paramTree_grid = {"criterion":["gini","entropy"],
                  "max_depth":np.arange(1, 32)
                 }
dtree_gscv = GridSearchCV(dec_tree, paramTree_grid, cv=5)
dtree_gscv.fit(X_trainDT, y_trainDT.ravel())
```




    GridSearchCV(cv=5, estimator=DecisionTreeClassifier(),
                 param_grid={'criterion': ['gini', 'entropy'],
                             'max_depth': array([ 1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16, 17,
           18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31])})




```python
dtree_gscv.best_params_
```




    {'criterion': 'entropy', 'max_depth': 24}




```python
dtree_gscv.best_score_
```




    0.5890755727578388




```python
modelDT = dtree_gscv.best_estimator_
```


```python
dtOpti = modelDT.score(X_testDT,y_testDT)
md(f"**<font color=#3a0ca3>Optimised Decision Tree</font>** accuracy: **<font color=#3a0ca3>{100*dtOpti:.2f}%</font>**")
```

    C:\Users\mayou\Anaconda3\lib\site-packages\sklearn\base.py:493: FutureWarning: The feature names should match those that were passed during fit. Starting version 1.2, an error will be raised.
    Feature names unseen at fit time:
    - Predict
    - True
    Feature names must be in the same order as they were in fit.
    
      warnings.warn(message, FutureWarning)
    


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-76-8f73aa2fefba> in <module>
    ----> 1 dtOpti = modelDT.score(X_testDT,y_testDT)
          2 md(f"**<font color=#3a0ca3>Optimised Decision Tree</font>** accuracy: **<font color=#3a0ca3>{100*dtOpti:.2f}%</font>**")
    

    ~\Anaconda3\lib\site-packages\sklearn\base.py in score(self, X, y, sample_weight)
        649         from .metrics import accuracy_score
        650 
    --> 651         return accuracy_score(y, self.predict(X), sample_weight=sample_weight)
        652 
        653     def _more_tags(self):
    

    ~\Anaconda3\lib\site-packages\sklearn\tree\_classes.py in predict(self, X, check_input)
        465         """
        466         check_is_fitted(self)
    --> 467         X = self._validate_X_predict(X, check_input)
        468         proba = self.tree_.predict(X)
        469         n_samples = X.shape[0]
    

    ~\Anaconda3\lib\site-packages\sklearn\tree\_classes.py in _validate_X_predict(self, X, check_input)
        431         """Validate the training data on predict (probabilities)."""
        432         if check_input:
    --> 433             X = self._validate_data(X, dtype=DTYPE, accept_sparse="csr", reset=False)
        434             if issparse(X) and (
        435                 X.indices.dtype != np.intc or X.indptr.dtype != np.intc
    

    ~\Anaconda3\lib\site-packages\sklearn\base.py in _validate_data(self, X, y, reset, validate_separately, **check_params)
        583 
        584         if not no_val_X and check_params.get("ensure_2d", True):
    --> 585             self._check_n_features(X, reset=reset)
        586 
        587         return out
    

    ~\Anaconda3\lib\site-packages\sklearn\base.py in _check_n_features(self, X, reset)
        399         if n_features != self.n_features_in_:
        400             raise ValueError(
    --> 401                 f"X has {n_features} features, but {self.__class__.__name__} "
        402                 f"is expecting {self.n_features_in_} features as input."
        403             )
    

    ValueError: X has 13 features, but DecisionTreeClassifier is expecting 11 features as input.


We can see that the best **<font color='#3a0ca3'>hyper-parameters</font>** are:  
* **criterion**: **<font color='#3a0ca3'>gini</font>**  
* **max_depth**: **<font color='#3a0ca3'>31</font>**  
  
The optimised model's accuracy is **<font color='#3a0ca3'>56.73%</font>** while the initial one is **<font color='#3a0ca3'>48.27%</font>.**

### <font color="#f72585">SVC</font>


```python
svc = SVC()
paramSvc_grid = {'C': [0.1, 1, 10, 100, 1000],
              'gamma': [1, 0.1, 0.01, 0.001, 0.0001],
              'kernel': ['rbf']}

svc_gscv = GridSearchCV(svc, paramSvc_grid, cv=5)
svc_gscv.fit(X_trainSvc, y_trainSvc.ravel())
```


```python
svc_gscv.best_params_
```


```python
svc_gscv.best_score_
```


```python
modelsvc = svc_gscv.best_estimator_
```


```python
svcOpti = modelsvc.score(X_testSvc,y_testSvc)
md(f"**<font color=#3a0ca3>Optimised SVC</font>** accuracy: **<font color=#3a0ca3>{100*svcOpti:.2f}%</font>**")
```

We can see that the best **<font color='#3a0ca3'>hyper-parameters</font>** are:  
* **C**: **<font color='#3a0ca3'>10</font>**
* **gamma**: **<font color='#3a0ca3'>1</font>**
* **kernel**: **<font color='#3a0ca3'>rbf</font>**

The optimised model's accuracy is **<font color='#3a0ca3'>62.45%</font>** while the initial one is **<font color='#3a0ca3'>53.47%</font>.**


```python
knnOptimal = round(100*knnOpti,2)
dtOptimal = round(100*dtOpti,2)
svcOptimal = round(100*svcOpti,2)
```


```python
fig = plt.figure(figsize=(10,8))
plt.bar(x=['KNN','Decision Tree', 'SVC'], height=[knnOptimal,dtOptimal,svcOptimal], 
        width=0.6, 
        color=['#3a0ca3','#e5e6e4','#cfd2cd'])
plt.text(0,knnOptimal-5,f'{knnOptimal}%',ha='center',fontsize=15, fontweight='bold', color='white')
plt.text(1,dtOptimal-5,f'{dtOptimal}%',ha='center',fontsize=15, fontweight='bold')
plt.text(2,svcOptimal-5,f'{svcOptimal}%',ha='center',fontsize=15, fontweight='bold')
plt.text(0.16,0.89,'KNN',transform=fig.transFigure, fontsize=16, fontweight='bold', color='#3a0ca3')
plt.text(0.22,0.89,'is the optimized model that has the',transform=fig.transFigure, fontsize=16)
plt.text(0.626,0.89,'highest accuracy.',transform=fig.transFigure, fontsize=16, fontweight='bold', color='#3a0ca3')
plt.xticks(fontsize=12)
plt.yticks([])
plt.title("Optimized models' accuracy comparison", fontsize=18, y=1.08)
plt.xlabel('Models',fontsize=15)
plt.gca().get_xticklabels()[0].set_color('#3a0ca3') 
sns.despine(left=True)
```

Finally, our best model seems to be the **<font color='#3a0ca3'>KNN</font>** model.

### <font color=#3a0ca3>d. Improvement</font> 

So far we have tested different **<font color=#3a0ca3>classifier's methods</font>** and even found the **<font color=#3a0ca3>best hyper-parameters</font>** for each of them to increase their accuracy. But the accuracy can still be improved by **<font color=#3a0ca3>combining</font>** those prediction using **<font color=#3a0ca3>ensemble methods</font>**. In our case we will use the **<font color=#3a0ca3>voting classifier</font>**, the **<font color=#3a0ca3>bagging classifier</font>** with **<font color=#3a0ca3>KNN</font>** as the **<font color=#3a0ca3>base estimator</font>** and finally the **<font color=#3a0ca3>Random forest</font>** which is also an ensemble method.

### <font color="#f72585">Voting classifier</font>


```python
X_trainVC,X_testVC,y_trainVC,y_testVC = train_test_split(df_scaled_features, targetReg, test_size=0.2, random_state=0)
```


```python
estimator = []
estimator.append(('KNN', KNeighborsClassifier(n_neighbors = 28, weights = 'distance', metric = 'manhattan')))
estimator.append(('DTC', DecisionTreeClassifier(criterion = 'gini', max_depth = 31)))
estimator.append(('SVC', SVC(C=10, gamma=1, kernel='rbf')))



```


```python
vot_hard = VotingClassifier(estimators = estimator, voting ='hard')
vot_hard.fit(X_trainVC, y_trainVC.ravel())
y_pred = vot_hard.predict(X_testVC)

md(f"Hard Voting Score: **<font color=#3a0ca3>{100*accuracy_score(y_testVC, y_pred):.2f}%</font>**")



# vot_soft = VotingClassifier(estimators = estimator, voting ='soft')
# vot_soft.fit(X_trainVC, y_trainVC.ravel())
# y_pred = vot_soft.predict(X_testVC)

# print("Soft Voting Score:",accuracy_score(y_testVC, y_pred))
```

### <font color="#f72585">Bagging classifier</font>


```python
from sklearn.ensemble import BaggingClassifier
```


```python
model = BaggingClassifier(base_estimator=KNeighborsClassifier(n_neighbors = 28, weights = 'distance', metric = 'manhattan'),n_estimators=100)
```


```python
model.fit(X_trainKnn, y_trainKnn.ravel())
baggingScore = model.score(X_testKnn, y_testKnn.ravel())

md(f"Bagging classifier Score: **<font color=#3a0ca3>{100*baggingScore:.2f}%</font>**")
```

### <font color="#f72585">Random Forest</font>


```python
X_trainRF,X_testRF,y_trainRF,y_testRF = train_test_split(df_scaled_features, targetReg, test_size=0.2, random_state=0)
```


```python
forest = RandomForestClassifier(n_estimators=100, criterion='gini', max_depth=31)
forest.fit(X_trainRF, y_trainRF.ravel())

y_pred_rf = forest.predict(X_testRF)
```


```python
print(classification_report(y_testRF, y_pred_rf.round(), digits=3))
```


```python
print("Wrong values predicted out of total values : ")
print((y_testRF!=y_pred_rf).sum(),'/',((y_testRF==y_pred_rf).sum()+(y_testRF!=y_pred_rf).sum()))
```


```python
md(f"Random Forest accuracy: **<font color=#3a0ca3>{100*accuracy_score(y_testRF,y_pred_rf):.2f}%</font>**")

```
